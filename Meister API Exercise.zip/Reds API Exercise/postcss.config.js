module.exports = {
    plugins: {
      autoprefixer: {}
    }
  }
  